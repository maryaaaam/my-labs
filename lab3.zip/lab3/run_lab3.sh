#!/bin/bash
# =============================================================================
# Lab 3 - Containerization and Cluster Orchestration
# Automated execution script – takes real terminal window screenshots
# =============================================================================

set -uo pipefail

LAB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCREENSHOTS_DIR="$LAB_DIR/screenshots"
LOG_FILE="$SCREENSHOTS_DIR/lab3_full_log.txt"

# ── ANSI colours ──────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

mkdir -p "$SCREENSHOTS_DIR"
: > "$LOG_FILE"

log()  { echo -e "${BLUE}${BOLD}[LAB3]${NC} $*" | tee -a "$LOG_FILE"; }
ok()   { echo -e "${GREEN}[✓]${NC} $*"           | tee -a "$LOG_FILE"; }
warn() { echo -e "${YELLOW}[!]${NC} $*"          | tee -a "$LOG_FILE"; }
err()  { echo -e "${RED}[✗]${NC} $*"             | tee -a "$LOG_FILE" >&2; }

header() {
    echo "" | tee -a "$LOG_FILE"
    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════${NC}" | tee -a "$LOG_FILE"
    echo -e "${CYAN}${BOLD}  $1${NC}" | tee -a "$LOG_FILE"
    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════${NC}" | tee -a "$LOG_FILE"
    echo "" | tee -a "$LOG_FILE"
}

# ── Screenshot engine ─────────────────────────────────────────────────────────
SCREENSHOT_TOOL=""
TERMINAL_WID=""

detect_screenshot_tool() {
    if [[ -z "${DISPLAY:-}" ]]; then
        warn "No \$DISPLAY – screenshots will be skipped (headless)."
        SCREENSHOT_TOOL="none"; return
    fi
    # Install scrot + xdotool if missing
    if ! command -v scrot &>/dev/null || ! command -v xdotool &>/dev/null; then
        log "Installing scrot and xdotool..."
        sudo apt-get install -y -qq scrot xdotool 2>/dev/null || true
    fi
    if command -v scrot &>/dev/null; then
        SCREENSHOT_TOOL="scrot"
    elif command -v import &>/dev/null; then
        SCREENSHOT_TOOL="import"
    elif command -v gnome-screenshot &>/dev/null; then
        SCREENSHOT_TOOL="gnome-screenshot"
    else
        warn "No screenshot tool available – screenshots will be skipped."
        SCREENSHOT_TOOL="none"; return
    fi
    # Capture terminal window ID once at startup
    if command -v xdotool &>/dev/null; then
        TERMINAL_WID=$(xdotool getactivewindow 2>/dev/null || \
                       xdotool getwindowfocus  2>/dev/null || echo "")
    fi
    ok "Screenshot tool: $SCREENSHOT_TOOL  |  window ID: ${TERMINAL_WID:-<full screen>}"
}

take_screenshot() {
    local imgfile="$1"
    [[ "$SCREENSHOT_TOOL" == "none" ]] && return 0
    sleep 0.7   # let the terminal finish rendering
    case "$SCREENSHOT_TOOL" in
        scrot)
            if [[ -n "$TERMINAL_WID" ]]; then
                scrot --window "$TERMINAL_WID" "$imgfile" 2>/dev/null || \
                scrot "$imgfile" 2>/dev/null || true
            else
                scrot "$imgfile" 2>/dev/null || true
            fi ;;
        import)
            if [[ -n "$TERMINAL_WID" ]]; then
                import -window "$TERMINAL_WID" "$imgfile" 2>/dev/null || \
                import -window root "$imgfile" 2>/dev/null || true
            else
                import -window root "$imgfile" 2>/dev/null || true
            fi ;;
        gnome-screenshot)
            gnome-screenshot -w -f "$imgfile" 2>/dev/null || \
            gnome-screenshot -f "$imgfile" 2>/dev/null || true ;;
    esac
    if [[ -f "$imgfile" ]]; then
        ok "Screenshot saved → screenshots/$(basename "$imgfile")"
    else
        warn "Screenshot capture failed for $(basename "$imgfile")"
    fi
}

# ── snap: clear terminal, print header, run command, screenshot ──────────────
SNAP_N=0
snap() {
    SNAP_N=$((SNAP_N + 1))
    local label="$1"; shift
    local tag; tag=$(printf "%02d_%s" "$SNAP_N" "$label")

    clear
    echo -e "${CYAN}${BOLD}$ $*${NC}"
    echo ""
    "$@" 2>&1 | tee -a "$LOG_FILE"

    take_screenshot "$SCREENSHOTS_DIR/${tag}.png"
}

# snap_sh: same but evaluates a shell expression (pipelines / heredocs)
snap_sh() {
    SNAP_N=$((SNAP_N + 1))
    local label="$1"; shift
    local tag; tag=$(printf "%02d_%s" "$SNAP_N" "$label")

    clear
    echo -e "${CYAN}${BOLD}# $label${NC}"
    echo ""
    eval "$*" 2>&1 | tee -a "$LOG_FILE"

    take_screenshot "$SCREENSHOTS_DIR/${tag}.png"
}

# watch_pods: kubectl get pods -w for N seconds then screenshot
watch_pods() {
    local label="$1"; local selector="$2"; local duration="${3:-25}"
    SNAP_N=$((SNAP_N + 1))
    local tag; tag=$(printf "%02d_%s" "$SNAP_N" "$label")

    clear
    echo -e "${CYAN}${BOLD}$ kubectl get pods -w -l $selector${NC}"
    echo ""
    timeout "$duration" kubectl get pods -w -l "$selector" 2>&1 | tee -a "$LOG_FILE" || true

    take_screenshot "$SCREENSHOTS_DIR/${tag}.png"
}

wait_pods_ready() {
    local selector="$1"; local timeout="${2:-120}"
    log "Waiting up to ${timeout}s for pods ($selector) to be ready..."
    kubectl wait --for=condition=ready pod -l "$selector" \
        --timeout="${timeout}s" 2>&1 | tee -a "$LOG_FILE" || \
        warn "Timed out waiting – continuing anyway"
}

# =============================================================================
cd "$LAB_DIR"
detect_screenshot_tool

# =============================================================================
# 0. PREREQUISITES
# =============================================================================
header "0 – Prerequisites Check"

for cmd in docker kind kubectl curl; do
    if command -v "$cmd" &>/dev/null; then
        ok "$cmd → $(command -v "$cmd")"
    else
        err "$cmd is NOT installed. Install it first, then re-run this script."
        exit 1
    fi
done

# =============================================================================
# PART A – Containers, Namespaces, and cgroups
# =============================================================================
header "PART A – Containers, Namespaces, and cgroups"

log "Task A1 – Namespace inspection inside a container"
docker rm -f nsdemo 2>/dev/null || true
docker run -d --name nsdemo ubuntu:22.04 sleep infinity
ok "nsdemo container started"
sleep 2

snap "A1_hostname" docker exec nsdemo hostname
snap "A1_ps_ef"    docker exec nsdemo ps -ef
snap "A1_ip_addr"  docker exec nsdemo ip addr
snap_sh "A1_mount" "docker exec nsdemo mount | head -20"
snap "A1_cgroup"   docker exec nsdemo cat /proc/1/cgroup

log "Task A2 – Host vs container process views"
snap "A2_docker_ps" docker ps

NSDEMO_PID=$(docker inspect nsdemo --format "{{.State.Pid}}")
snap_sh "A2_inspect_pid" "echo 'Container .State.Pid on host: $NSDEMO_PID'"
snap    "A2_host_ps_fp"  ps -fp "$NSDEMO_PID"

snap_sh "A2_pid_namespace_note" "cat <<'EOF'

  PID Namespace Explanation
  ──────────────────────────────────────────────────────────────
  The container believes its main process is PID 1 because the
  PID namespace creates an isolated numbering space.  The kernel
  maps the container PID 1 to host PID $NSDEMO_PID.
  The host sees all PIDs; the container only sees its own namespace.
EOF"

docker rm -f nsdemo 2>/dev/null || true

log "Task A3 – Resource limits with cgroups"
docker rm -f stress-demo 2>/dev/null || true
docker run -d --name stress-demo --cpus="0.5" --memory="256m" \
    ubuntu:22.04 sleep infinity
sleep 2

log "Installing stress inside container..."
docker exec stress-demo bash -c \
    "apt-get update -qq && apt-get install -y -qq stress" 2>&1 | tee -a "$LOG_FILE"

log "Starting stress workload (30 s)..."
docker exec -d stress-demo stress --cpu 2 --vm 1 --vm-bytes 220M --timeout 30
sleep 5

snap "A3_docker_stats" docker stats --no-stream stress-demo

snap_sh "A3_cgroups_note" "cat <<'EOF'

  cgroups vs Namespaces
  ──────────────────────────────────────────────────────────────
  Namespaces  isolate VISIBILITY  (process tree, network, mounts)
  cgroups     control RESOURCE USE (CPU, memory, I/O, bandwidth)
  A container runtime sets up BOTH: isolated view + enforced caps.
EOF"

docker rm -f stress-demo 2>/dev/null || true
ok "Part A complete"

# =============================================================================
# PART B – Docker Image Layering
# =============================================================================
header "PART B – Docker Image Layering"

snap "B2_build_basic"    docker build -f Dockerfile.basic   -t lab3-basic .
snap "B2_history_basic"  docker history lab3-basic
snap "B2_image_ls_basic" docker image ls lab3-basic

snap "B3_build_multi"   docker build -f Dockerfile.multistage -t lab3-multi .
snap "B3_history_multi" docker history lab3-multi

snap_sh "B3_image_comparison" "
echo ''
echo '  Docker Image Size Comparison'
echo '  ══════════════════════════════════════════════════'
docker image ls --format 'table {{.Repository}}\t{{.Tag}}\t{{.Size}}\t{{.ID}}' \
    | grep -E 'REPOSITORY|lab3'
echo ''
BASIC_LAYERS=\$(docker history lab3-basic --quiet | wc -l)
MULTI_LAYERS=\$(docker history lab3-multi --quiet | wc -l)
echo \"  Layers – lab3-basic  : \$BASIC_LAYERS\"
echo \"  Layers – lab3-multi  : \$MULTI_LAYERS\"
echo ''
echo '  Analysis:'
echo '  • Multi-stage is smaller – builder stage discarded, only packages kept.'
echo '  • Only app.py changed → pip install layers are cache-hits.'
echo '  • Slow/stable layers first, app code last = maximum cache reuse.'
"
ok "Part B complete"

# =============================================================================
# PART C – Local Kubernetes Orchestration with kind
# =============================================================================
header "PART C – Local Kubernetes Orchestration with kind"

if kind get clusters 2>/dev/null | grep -q "^lab3-cluster$"; then
    warn "Cluster 'lab3-cluster' already exists – reusing."
    snap "C1_cluster_exists" kind get clusters
else
    snap "C1_create_cluster" kind create cluster --name lab3-cluster
fi

snap "C1_cluster_info" kubectl cluster-info --context kind-lab3-cluster
snap "C1_get_nodes"    kubectl get nodes -o wide --context kind-lab3-cluster

snap "C2_load_basic" kind load docker-image lab3-basic --name lab3-cluster
snap "C2_load_multi" kind load docker-image lab3-multi --name lab3-cluster

# Label nodes first so nodeSelector in deployment.yaml is satisfied
header "PART D – Scheduling and Placement"
snap "D1_label_nodes" kubectl label nodes --all node-role=general --overwrite
snap "D1_show_labels" kubectl get nodes --show-labels

header "PART C continued – Deploy application"
snap "C3_apply_deployment" kubectl apply -f deployment.yaml
snap "C3_apply_service"    kubectl apply -f service.yaml

wait_pods_ready "app=lab3-web" 120

snap "C3_get_pods"        kubectl get pods -o wide
snap "C3_get_deployments" kubectl get deployments
snap "C3_describe_deploy" kubectl describe deployment lab3-web

kubectl port-forward service/lab3-web-svc 8080:80 &
PF_PID=$!
for i in $(seq 1 15); do
    sleep 1
    if curl -s --max-time 2 http://localhost:8080/ &>/dev/null; then
        ok "Port-forward live after ${i}s"; break
    fi
done

snap "C4_curl_root"   curl -s http://localhost:8080/
snap "C4_curl_health" curl -s http://localhost:8080/health

kill "$PF_PID" 2>/dev/null || true
wait "$PF_PID" 2>/dev/null || true
ok "Part C complete"

# =============================================================================
# PART D continued – Placement verification
# =============================================================================
header "PART D continued – Placement verification"
snap "D2_nodeSelector_yaml" kubectl get deployment lab3-web -o yaml
snap_sh "D2_pod_placement" "
echo ''
echo '  Pod placement (node column)'
echo '  ══════════════════════════════════════════════════'
kubectl get pods -o wide
echo ''
echo '  nodeSelector forces pods onto nodes labelled node-role=general.'
echo '  Unlike hard-coding a machine name:'
echo '    • Any matching node is eligible  → resilient to node failure'
echo '    • Label a new node to add capacity instantly'
echo '    • Declaration is version-controlled, not tied to infra topology'
"
ok "Part D complete"

# =============================================================================
# PART E – Self-healing and Health Probes
# =============================================================================
header "PART E – Self-healing and Health Probes"

snap "E1_pods_before_delete" kubectl get pods

POD_TO_DELETE=$(kubectl get pods -l app=lab3-web \
    -o jsonpath='{.items[0].metadata.name}')
log "Deleting pod: $POD_TO_DELETE"

watch_pods "E1_pod_recovery_watch" "app=lab3-web" 30 &
WATCHER_PID=$!
sleep 1

snap "E1_delete_pod" kubectl delete pod "$POD_TO_DELETE"
wait "$WATCHER_PID" 2>/dev/null || true

sleep 5
snap "E1_pods_after_heal" kubectl get pods

snap_sh "E1_reconciliation_note" "cat <<'EOF'

  Reconciliation vs Simple Restart
  ──────────────────────────────────────────────────────────────
  Kubernetes compares DESIRED state (3 replicas) with ACTUAL state
  (2 after deletion) and creates a brand-new Pod to close the gap.
  This loop fires on every event – self-corrects even when multiple
  pods fail simultaneously or entire nodes disappear.
EOF"

snap "E2_apply_probe_deploy" kubectl apply -f probe-deployment.yaml
wait_pods_ready "app=lab3-web-probe" 120
snap "E2_get_pods_probe" kubectl get pods -l app=lab3-web-probe

PROBE_POD=$(kubectl get pods -l app=lab3-web-probe \
    -o jsonpath='{.items[0].metadata.name}')
snap "E2_describe_probe_pod" kubectl describe pod "$PROBE_POD"

snap_sh "E2_probes_note" "cat <<'EOF'

  Readiness vs Liveness Probes
  ──────────────────────────────────────────────────────────────
  Liveness  → Is the container alive (not deadlocked)?
    Failure: Kubernetes RESTARTS the container.
  Readiness → Is the container ready to accept traffic?
    Failure: Pod REMOVED from Service endpoints (no restart).

  NOT interchangeable:
    Liveness on slow-start app → unnecessary restart loop
    Readiness on deadlocked app → silently drops traffic
EOF"

snap "E3_ps_in_pod" kubectl exec "$PROBE_POD" -- ps -ef

watch_pods "E3_pod_watch_after_kill" "app=lab3-web-probe" 35 &
WATCHER_PID=$!
sleep 1

log "Sending kill 1 to $PROBE_POD..."
kubectl exec "$PROBE_POD" -- kill 1 2>&1 | tee -a "$LOG_FILE" || true
wait "$WATCHER_PID" 2>/dev/null || true

sleep 5
snap_sh "E3_pods_after_kill" "
kubectl get pods -l app=lab3-web-probe \
    -o custom-columns='NAME:.metadata.name,RESTARTS:.status.containerStatuses[0].restartCount,STATUS:.status.phase'
echo ''
echo '  Pod NAME unchanged – RESTARTS counter increased.'
echo '  kubelet restarted the CONTAINER in-place (container exited, Pod is fine).'
echo '  A brand-new Pod is only created when the whole Pod is deleted/node lost.'
"
ok "Part E complete"

# =============================================================================
# REFLECTION ANSWERS – shown in terminal and screenshot
# =============================================================================
header "D5 – Reflection Answers"

cat <<'REFLECTION' | tee -a "$LOG_FILE"

  1. Namespaces alone don't guarantee fair resource use – they isolate
     visibility only. A process can still consume 100% CPU / all RAM.
     cgroups impose the quantitative caps.

  2. cgroups improve cluster stability by enforcing hard limits per container,
     preventing runaway workloads from starving neighbours (noisy-neighbour)
     and stopping cascading OOM kills.

  3. Image layering is critical at scale: layers are content-addressed and
     cached per node.  Only changed layers are pulled on rollout, cutting
     update time from minutes to seconds.

  4. Desired state means the operator declares WHAT should exist (e.g. "3
     replicas of lab3-multi").  Kubernetes reconciles actual → desired
     automatically – no imperative restart scripts needed.

  5. Self-healing is automatic (seconds); traditional ops require alert →
     page → SSH → manual restart → verify, with human-error risk.

  6. Liveness restarts the container (deadlocks); readiness removes it from
     traffic (slow start / overload).  Swapping them causes restart loops
     or silent traffic drops.

  7. Single-node kind cannot show spread across failure domains, pod
     relocation when a node drains, anti-affinity, or scheduler decisions
     based on per-node resource pressure.

REFLECTION

take_screenshot "$SCREENSHOTS_DIR/$(printf "%02d" $((SNAP_N+1)))_D5_reflection.png"
SNAP_N=$((SNAP_N+1))

# =============================================================================
# SUMMARY
# =============================================================================
header "Lab 3 Complete"

echo -e "${GREEN}${BOLD}Screenshots saved to:${NC} $SCREENSHOTS_DIR/" | tee -a "$LOG_FILE"
ls -1 "$SCREENSHOTS_DIR/"*.png 2>/dev/null | while read -r f; do
    echo "  $(basename "$f")"
done | tee -a "$LOG_FILE"
echo ""
echo -e "${YELLOW}Cleanup:${NC}"
echo "  kubectl delete -f $LAB_DIR/deployment.yaml"
echo "  kubectl delete -f $LAB_DIR/service.yaml"
echo "  kubectl delete -f $LAB_DIR/probe-deployment.yaml"
echo "  kind delete cluster --name lab3-cluster"
echo ""
ok "run_lab3.sh finished successfully!"
